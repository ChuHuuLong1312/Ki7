/** Automatically generated file. DO NOT MODIFY */
package com.deitel.welcome;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}